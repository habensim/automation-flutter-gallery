import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;

public class SwipeTest {
}

